package org.ncu.movieservice.repository;

import org.ncu.movieservice.entity.Movie;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MovieRepository extends JpaRepository<Movie, Long> {
    Movie findByMovieName(String movieName);
    Movie findByMovieId(long movieId);
}
