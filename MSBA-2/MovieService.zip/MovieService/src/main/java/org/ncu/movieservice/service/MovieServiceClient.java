package org.ncu.movieservice.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class MovieServiceClient {

    @Value("${theatre.service.url}")
    private String theatreServiceUrl; // The base URL of the Theatre-Service

    private final RestTemplate restTemplate;

    public MovieServiceClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public ResponseEntity<String> getTheatreById(Long theatreId) {
        String url = theatreServiceUrl + "/theatres/{theatreId}";
        return restTemplate.getForEntity(url, String.class, theatreId);
    }

    // Additional methods for communication with Theatre-Service

}
