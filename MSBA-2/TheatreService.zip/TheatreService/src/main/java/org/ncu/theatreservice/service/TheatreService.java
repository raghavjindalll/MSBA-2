package org.ncu.theatreservice.service;

import org.ncu.theatreservice.entity.Theatre;
import org.ncu.theatreservice.repository.TheatreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TheatreService {

    private final TheatreRepository theatreRepository;

    @Autowired
    public TheatreService(TheatreRepository theatreRepository) {
        this.theatreRepository = theatreRepository;
    }

    public Theatre findByTheatreId(Long theatreId) {
        return theatreRepository.findByTheatreId(theatreId);
    }

    public Theatre findByTheatreNameAndTheatreCity(String theatreName, String theatreCity) {
        return theatreRepository.findByTheatreNameAndTheatreCity(theatreName, theatreCity);
    }

    // Other service methods for Theatre-Service

}
