package org.ncu.theatreservice.entity;

import jakarta.persistence.Embeddable;

@Embeddable
public class Screen {
    private Long screenId;
    private Long theatreId;
    private int seatsNumber;

    // Constructors, getters, and setters

    public Long getScreenId() {
        return screenId;
    }

    public void setScreenId(Long screenId) {
        this.screenId = screenId;
    }

    public Long getTheatreId() {
        return theatreId;
    }

    public void setTheatreId(Long theatreId) {
        this.theatreId = theatreId;
    }

    public int getSeatsNumber() {
        return seatsNumber;
    }

    public void setSeatsNumber(int seatsNumber) {
        this.seatsNumber = seatsNumber;
    }
}
