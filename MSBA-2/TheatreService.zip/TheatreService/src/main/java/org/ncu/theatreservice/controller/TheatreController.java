package org.ncu.theatreservice.controller;

import org.ncu.theatreservice.entity.Theatre;
import org.ncu.theatreservice.service.TheatreService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

@Controller
@RequestMapping("/theatres")
public class TheatreController {

    private final TheatreService theatreService;
    private final RestTemplate restTemplate;

    @Value("${movie.service.url}")
    private String movieServiceUrl; // The base URL of the Movie-Service

    public TheatreController(TheatreService theatreService, RestTemplate restTemplate) {
        this.theatreService = theatreService;
        this.restTemplate = restTemplate;
    }

    @GetMapping("/{theatreId}")
    @ResponseBody
    public Theatre getTheatreById(@PathVariable Long theatreId) {
        String url = movieServiceUrl + "/movies/theatre/{theatreId}";
        return restTemplate.getForObject(url, Theatre.class, theatreId);
    }

    // Additional methods for Theatre-Service

}
